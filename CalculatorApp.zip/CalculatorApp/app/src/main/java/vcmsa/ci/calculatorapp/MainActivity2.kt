package vcmsa.ci.calculatorapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity2 : AppCompatActivity() {

    private lateinit var etNumber: EditText
    private lateinit var etMemory: EditText
    private lateinit var etAnswer: EditText
    private lateinit var btnAdd: Button
    private lateinit var btnClear: Button
    private lateinit var btnFind: Button
    private lateinit var btnMinMax: Button
    private lateinit var btnBasic: Button

    private val numbersList = mutableListOf<Double>() // Stores numbers added in memory

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main2)

        etNumber = findViewById(R.id.etNumber)
        etMemory = findViewById(R.id.etMemory)
        etAnswer = findViewById(R.id.etAnswer)
        btnAdd = findViewById(R.id.btnAdd)
        btnClear = findViewById(R.id.btnClear)
        btnFind = findViewById(R.id.btnFind)
        btnMinMax = findViewById(R.id.btnMinMax)
        btnBasic = findViewById(R.id.btnBasic)

        btnAdd.setOnClickListener { addNumber() }
        btnClear.setOnClickListener { clearMemory() }
        btnFind.setOnClickListener { findAverage() }
        btnMinMax.setOnClickListener { findMinMax() }
        btnBasic.setOnClickListener { goToBasicCalculator() }
    }

    private fun addNumber() {
        val inputText = etNumber.text.toString()
        if (inputText.isNotEmpty()) {
            val number = inputText.toDoubleOrNull()
            if (number != null) {
                numbersList.add(number)
                etMemory.setText(numbersList.joinToString(", ")) // Display stored numbers
                etNumber.text.clear()
            } else {
                etNumber.error = "Enter a valid number"
            }
        } else {
            etNumber.error = "Field cannot be empty"
        }
    }

    private fun clearMemory() {
        numbersList.clear()
        etMemory.setText("")
        etAnswer.setText("")
    }

    private fun findAverage() {
        if (numbersList.isNotEmpty()) {
            val average = numbersList.average()
            etAnswer.setText(average.toString())
        } else {
            etAnswer.setText("No numbers in memory")
        }
    }

    private fun findMinMax() {
        if (numbersList.isNotEmpty()) {
            val min = numbersList.minOrNull()
            val max = numbersList.maxOrNull()
            etAnswer.setText("Min: $min, Max: $max")
        } else {
            etAnswer.setText("No numbers in memory")
        }
    }

    private fun goToBasicCalculator() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}
