package vcmsa.ci.calculatorapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var etNumber1: EditText
    private lateinit var etNumber2: EditText
    private lateinit var tvHeader: TextView
    private lateinit var tvAnswer: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        etNumber1 = findViewById(R.id.etNumber1)
        etNumber2 = findViewById(R.id.etNumber2)
        tvHeader = findViewById(R.id.tvHeader)
        tvAnswer = findViewById(R.id.tvAnswer)

        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnSub = findViewById<Button>(R.id.btnSub)
        val btnDiv = findViewById<Button>(R.id.btnDiv)
        val btnMulti = findViewById<Button>(R.id.btnMulti)
        val btnSquare = findViewById<Button>(R.id.btnSquare)
        val btnPower = findViewById<Button>(R.id.btnPower)
        val btnStats = findViewById<Button>(R.id.btnStats)

        btnAdd.setOnClickListener {
            add() }

        btnSub.setOnClickListener {
            sub() }

        btnDiv.setOnClickListener {
            div() }

        btnMulti.setOnClickListener {
            multi() }

        btnSquare.setOnClickListener {
            squareRoot() }

        btnPower.setOnClickListener {
            power() }

        btnStats.setOnClickListener {
            val intent = Intent(this, MainActivity2::class.java)
            startActivity(intent)
        }
    }

    private fun inputIsNotEmpty(): Boolean {
        var isValid = true

        if (etNumber1.text.toString().trim().isEmpty()) {
            etNumber1.error = "Required"
            tvAnswer.text = "Input Required"
            isValid = false
        }

        if (etNumber2.text.toString().trim().isEmpty()) {
            etNumber2.error = "Required"
            tvAnswer.text = "Input Required"
            isValid = false
        }

        return isValid
    }

    private fun isNotZero(): Boolean {
        val number2 = etNumber2.text.toString().trim()

        return if (number2 == "0") {
            etNumber2.error = "Cannot divide by zero!"
            tvAnswer.text = "Cannot divide by zero!"
            false
        } else {
            true
        }
    }

    private fun add() {
        if (inputIsNotEmpty()) {
            val num1 = etNumber1.text.toString().toDouble()
            val num2 = etNumber2.text.toString().toDouble()
            tvAnswer.text = "Answer: ${num1 + num2}"
        }
    }

    private fun sub() {
        if (inputIsNotEmpty()) {
            val num1 = etNumber1.text.toString().toDouble()
            val num2 = etNumber2.text.toString().toDouble()
            tvAnswer.text = "Answer: ${num1 - num2}"
        }
    }

    private fun multi() {
        if (inputIsNotEmpty()) {
            val num1 = etNumber1.text.toString().toDouble()
            val num2 = etNumber2.text.toString().toDouble()
            tvAnswer.text = "Answer: ${num1 * num2}"
        }
    }

    private fun div() {
        if (inputIsNotEmpty() && isNotZero()) {
            val num1 = etNumber1.text.toString().toDouble()
            val num2 = etNumber2.text.toString().toDouble()
            tvAnswer.text = "Answer: ${num1 / num2}"
        }
    }

    private fun squareRoot() {
        if (inputIsNotEmpty()) {
            val num = etNumber1.text.toString().toDouble()
            tvAnswer.text = "Answer: ${Math.sqrt(num)}"
        }
    }

    private fun power() {
        if (inputIsNotEmpty()) {
            val num1 = etNumber1.text.toString().toDouble()
            val num2 = etNumber2.text.toString().toDouble()
            tvAnswer.text = "Answer: ${Math.pow(num1, num2)}"
        }
    }
}